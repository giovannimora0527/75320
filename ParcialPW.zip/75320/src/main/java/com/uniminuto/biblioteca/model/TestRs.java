
package com.uniminuto.biblioteca.model;

import lombok.Data;

/**
 *
 * @author lmora
 */
@Data
public class TestRs {
    private Integer status;
    private String message;
}
